<?php
$amount = $_POST['amount'];
$card-number = $_POST['card-number'];
$expiry = $_POST['expiry'];
$cvv = $_POST['cvv'];
//Database connection
?>